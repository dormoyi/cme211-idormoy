The purpose of the code is to determine if a truss is balanced or not. For that, we use
the joints method to solve the equation for every joint.
